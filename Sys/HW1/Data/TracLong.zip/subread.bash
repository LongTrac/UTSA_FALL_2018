#!/bin/bash
# This bash file will help the update and read.bash to read the 
#specific file into variable

read r_sim_name r_name
read r_quan r_max
read r_des

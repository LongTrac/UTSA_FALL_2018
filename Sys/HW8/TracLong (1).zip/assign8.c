#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include "cmdparse.h" 
#include <sys/wait.h>

int main()
{
	long lForkPid;
	long lwaitPid;
	int iExitStatus; 
	char szBuffer[151];
	char szInput[51];
	int iParseCmd;
	CMD cmd;

	//While loop 
	while (1)
	{	
		printf("$ ");
		// get the input from the user 
		fgets (szBuffer, sizeof(szBuffer),stdin);
		sscanf (szBuffer, "%s", szInput);

		//if it the command is exit : exit the shell
		if (strcmp (szInput, "exit") == 0)
			return 0;

		//parse cmd using the provided function
		iParseCmd = cmdparse(szBuffer,&cmd);

		if (iParseCmd != 1)
		{
			// create a child process
			lForkPid = fork();

			switch(lForkPid)
			{
				case -1:
					//errExit("fork failed: %s", strerror(errno));
					fprintf(stderr,"Fork failed.\n");
					return(1);
					break;
				//if it is the child process, run the code in this case 0
				case 0:  // child process
					//Execute a cmd
					execvp (cmd.argv1[0],cmd.argv1);
					//errExit("Child process failed to exec: %s", strerror(errno));
					fprintf(stderr,"%s: command not found.\n",cmd.argv1[0]);

					return(1);
					break;
				default: // parent process

					if (cmd.background == 1){
						break;
					}
					lwaitPid = wait (&iExitStatus);
					if (lwaitPid == -1)
					{

						fprintf(stderr,"Wait error.\n");
						return(1);
					
					}
					//errExit("wait error: %s", strerror(errno));
			}
		}
		else
		{
			fprintf(stderr, "Parse Error.\n");
		}

	}

	return 0;
}	

